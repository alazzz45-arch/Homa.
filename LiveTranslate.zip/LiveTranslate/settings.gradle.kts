pluginManagement {
    repositories { google(); mavenCentral(); gradlePluginPortal() }
}
dependencyResolutionManagement {
    repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS)
    repositories { google(); mavenCentral() }
}
rootProject.name = "LiveTranslate"
include(":app")

// Prints the real Gradle error as a GitHub annotation so it is easy to read.
gradle.addBuildListener(object : org.gradle.BuildAdapter() {
    override fun buildFinished(result: org.gradle.BuildResult) {
        val f = result.failure ?: return
        val sb = StringBuilder()
        var t: Throwable? = f
        while (t != null) { sb.append(t.message).append(" || "); t = t.cause }
        val msg = sb.toString().take(3500)
            .replace("%", "%25").replace("\r", "").replace("\n", "%0A")
        println("::error title=GRADLE ERROR::" + msg)
    }
})
