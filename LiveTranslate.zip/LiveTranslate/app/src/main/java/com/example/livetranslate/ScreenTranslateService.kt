package com.example.livetranslate

import android.accessibilityservice.AccessibilityService
import android.graphics.PixelFormat
import android.graphics.Rect
import android.graphics.RectF
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.widget.TextView
import com.google.mlkit.common.model.DownloadConditions
import com.google.mlkit.nl.languageid.LanguageIdentification
import com.google.mlkit.nl.translate.TranslateLanguage
import com.google.mlkit.nl.translate.Translation
import com.google.mlkit.nl.translate.Translator
import com.google.mlkit.nl.translate.TranslatorOptions

/**
 * Translates what is on screen by reading the app's text nodes directly
 * (no screenshot, no OCR). Everything runs on-device.
 */
class ScreenTranslateService : AccessibilityService() {

    private data class Line(val box: Rect, val text: String)

    private val main = Handler(Looper.getMainLooper())
    private lateinit var wm: WindowManager
    private lateinit var overlay: OverlayView
    private lateinit var button: TextView
    private val langId = LanguageIdentification.getClient()
    private val translators = HashMap<String, Translator>()
    private val cache = HashMap<String, String>()   // text -> translation ("" = skip)
    private val pending = HashSet<String>()
    private var lines: List<Line> = emptyList()
    private var active = false

    private val refresh = Runnable { scan() }

    override fun onServiceConnected() {
        wm = getSystemService(WINDOW_SERVICE) as WindowManager

        overlay = OverlayView(this)
        wm.addView(overlay, WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ))

        button = TextView(this).apply {
            text = "ترجمة"
            setTextColor(0xFFFFFFFF.toInt())
            setBackgroundColor(0xCC1565C0.toInt())
            setPadding(36, 24, 36, 24)
            setOnClickListener { toggle() }
        }
        wm.addView(button, WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.END or Gravity.CENTER_VERTICAL })
    }

    private fun toggle() {
        active = !active
        button.text = if (active) "إيقاف" else "ترجمة"
        if (active) scan() else { lines = emptyList(); overlay.setItems(emptyList()) }
    }

    override fun onAccessibilityEvent(e: AccessibilityEvent) {
        if (!active) return
        if (e.eventType == AccessibilityEvent.TYPE_VIEW_SCROLLED) overlay.setItems(emptyList())
        main.removeCallbacks(refresh)
        main.postDelayed(refresh, 500)
    }

    private fun scan() {
        val root = rootInActiveWindow ?: return
        val found = ArrayList<Line>()
        collect(root, found)
        lines = found
        found.forEach { translate(it.text) }
        render()
    }

    private fun collect(n: AccessibilityNodeInfo, out: MutableList<Line>) {
        if (!n.isVisibleToUser) return
        val t = (n.text ?: n.contentDescription)?.toString()?.trim()
        if (!t.isNullOrEmpty() && t.length >= 2 && n.childCount == 0 && !n.isPassword) {
            val r = Rect(); n.getBoundsInScreen(r)
            if (r.width() > 0 && r.height() > 0) out.add(Line(r, t))
        }
        for (i in 0 until n.childCount) n.getChild(i)?.let { collect(it, out) }
    }

    private fun translate(text: String) {
        if (cache.containsKey(text) || !pending.add(text)) return
        langId.identifyLanguage(text).addOnSuccessListener { tag ->
            val src = TranslateLanguage.fromLanguageTag(tag)
            if (tag == "und" || tag == "ar" || src == null) { done(text, ""); return@addOnSuccessListener }
            val tr = translators.getOrPut(src) {
                Translation.getClient(
                    TranslatorOptions.Builder()
                        .setSourceLanguage(src)
                        .setTargetLanguage(TranslateLanguage.ARABIC).build()
                )
            }
            // Needs internet only the first time for each language.
            tr.downloadModelIfNeeded(DownloadConditions.Builder().build())
                .addOnSuccessListener {
                    tr.translate(text)
                        .addOnSuccessListener { done(text, it) }
                        .addOnFailureListener { pending.remove(text) }
                }
                .addOnFailureListener { pending.remove(text) }
        }.addOnFailureListener { pending.remove(text) }
    }

    private fun done(text: String, result: String) {
        cache[text] = result; pending.remove(text)
        if (active) render()
    }

    private fun render() {
        val loc = IntArray(2); overlay.getLocationOnScreen(loc)
        overlay.setItems(lines.mapNotNull { l ->
            val t = cache[l.text]
            if (t.isNullOrEmpty() || t == l.text) null
            else OverlayItem(RectF(l.box).apply { offset(-loc[0].toFloat(), -loc[1].toFloat()) }, t)
        })
    }

    override fun onInterrupt() {}

    override fun onDestroy() {
        super.onDestroy()
        main.removeCallbacksAndMessages(null)
        translators.values.forEach { it.close() }
        langId.close()
        runCatching { wm.removeView(overlay); wm.removeView(button) }
    }
}
