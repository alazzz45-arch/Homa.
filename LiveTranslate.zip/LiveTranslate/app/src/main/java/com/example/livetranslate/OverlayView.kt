package com.example.livetranslate

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.text.Layout
import android.text.StaticLayout
import android.text.TextPaint
import android.util.AttributeSet
import android.view.View

data class OverlayItem(val box: RectF, val text: String)

class OverlayView @JvmOverloads constructor(
    context: Context, attrs: AttributeSet? = null
) : View(context, attrs) {

    private var items: List<OverlayItem> = emptyList()
    private val bg = Paint().apply { color = Color.argb(225, 20, 20, 20) }
    private val tp = TextPaint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE }

    fun setItems(newItems: List<OverlayItem>) {
        items = newItems
        postInvalidateOnAnimation()
    }

    override fun onDraw(canvas: Canvas) {
        for (it in items) {
            val w = it.box.width().toInt().coerceAtLeast(40)
            canvas.drawRect(it.box, bg)
            // Shrink text until it fits the original box height.
            var size = (it.box.height() * 0.8f).coerceIn(16f, 64f)
            var layout: StaticLayout
            while (true) {
                tp.textSize = size
                layout = StaticLayout.Builder
                    .obtain(it.text, 0, it.text.length, tp, w)
                    .setAlignment(Layout.Alignment.ALIGN_NORMAL)
                    .build()
                if (layout.height <= it.box.height() * 1.6f || size <= 14f) break
                size -= 2f
            }
            canvas.save()
            canvas.translate(it.box.left, it.box.top)
            layout.draw(canvas)
            canvas.restore()
        }
    }
}
