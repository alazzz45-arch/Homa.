package com.example.livetranslate

import android.Manifest
import android.content.pm.PackageManager
import android.graphics.RectF
import android.os.Bundle
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Spinner
import android.widget.TextView
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.camera.core.*
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.core.content.ContextCompat
import com.google.mlkit.common.model.DownloadConditions
import com.google.mlkit.nl.translate.*
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import java.util.concurrent.Executors

/** OCR here is Latin-script only (ML Kit). Target language is Arabic. */
class MainActivity : ComponentActivity() {

    private data class Line(val box: RectF, val text: String)

    private lateinit var previewView: PreviewView
    private lateinit var overlay: OverlayView
    private lateinit var status: TextView

    private val recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
    private val analysisExecutor = Executors.newSingleThreadExecutor()

    private val langs = listOf(
        "الإنجليزية" to TranslateLanguage.ENGLISH,
        "الفرنسية" to TranslateLanguage.FRENCH,
        "الإسبانية" to TranslateLanguage.SPANISH,
        "الألمانية" to TranslateLanguage.GERMAN,
        "الإيطالية" to TranslateLanguage.ITALIAN,
        "التركية" to TranslateLanguage.TURKISH,
    )

    private var translator: Translator? = null
    private var modelReady = false
    private val cache = HashMap<String, String>()
    private val pending = HashSet<String>()
    private var lastLines: List<Line> = emptyList()
    private var lastAnalysis = 0L

    private val permission = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted -> if (granted) startCamera() else status.text = "مطلوب إذن الكاميرا" }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        previewView = findViewById(R.id.previewView)
        previewView.scaleType = PreviewView.ScaleType.FIT_CENTER
        overlay = findViewById(R.id.overlay)
        status = findViewById(R.id.status)

        findViewById<android.widget.Button>(R.id.screenBtn).setOnClickListener {
            startActivity(android.content.Intent(android.provider.Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }
        val spinner = findViewById<Spinner>(R.id.sourceSpinner)
        spinner.adapter = ArrayAdapter(
            this, android.R.layout.simple_spinner_dropdown_item, langs.map { it.first }
        )
        spinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(p: AdapterView<*>?, v: android.view.View?, pos: Int, id: Long) =
                setSource(langs[pos].second)
            override fun onNothingSelected(p: AdapterView<*>?) {}
        }

        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA)
            == PackageManager.PERMISSION_GRANTED) startCamera()
        else permission.launch(Manifest.permission.CAMERA)
    }

    private fun setSource(src: String) {
        translator?.close()
        cache.clear(); pending.clear(); lastLines = emptyList(); modelReady = false
        overlay.setItems(emptyList())
        val t = Translation.getClient(
            TranslatorOptions.Builder()
                .setSourceLanguage(src)
                .setTargetLanguage(TranslateLanguage.ARABIC)
                .build()
        )
        translator = t
        status.text = "تحميل النموذج…"
        // First time needs internet; afterwards works fully offline.
        t.downloadModelIfNeeded(DownloadConditions.Builder().build())
            .addOnSuccessListener { if (translator === t) { modelReady = true; status.text = "جاهز (بدون إنترنت)" } }
            .addOnFailureListener { status.text = "فشل التحميل: يلزم إنترنت لأول مرة" }
    }

    private fun startCamera() {
        val future = ProcessCameraProvider.getInstance(this)
        future.addListener({
            val provider = future.get()
            val preview = Preview.Builder().build().also { it.setSurfaceProvider(previewView.surfaceProvider) }
            val analysis = ImageAnalysis.Builder()
                .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                .build()
            analysis.setAnalyzer(analysisExecutor) { proxy -> analyze(proxy) }
            provider.unbindAll()
            provider.bindToLifecycle(this, CameraSelector.DEFAULT_BACK_CAMERA, preview, analysis)
        }, ContextCompat.getMainExecutor(this))
    }

    private fun analyze(proxy: ImageProxy) {
        val now = System.currentTimeMillis()
        val media = proxy.image
        if (media == null || !modelReady || now - lastAnalysis < 400) { proxy.close(); return }
        lastAnalysis = now

        val rot = proxy.imageInfo.rotationDegrees
        val imgW = if (rot == 90 || rot == 270) proxy.height else proxy.width
        val imgH = if (rot == 90 || rot == 270) proxy.width else proxy.height

        recognizer.process(InputImage.fromMediaImage(media, rot))
            .addOnSuccessListener(ContextCompat.getMainExecutor(this)) { result ->
                val vw = previewView.width.toFloat()
                val vh = previewView.height.toFloat()
                val scale = minOf(vw / imgW, vh / imgH)
                val dx = (vw - imgW * scale) / 2f
                val dy = (vh - imgH * scale) / 2f
                lastLines = result.textBlocks.flatMap { it.lines }.mapNotNull { l ->
                    val b = l.boundingBox ?: return@mapNotNull null
                    if (l.text.length < 2) return@mapNotNull null
                    Line(RectF(b.left * scale + dx, b.top * scale + dy,
                               b.right * scale + dx, b.bottom * scale + dy), l.text)
                }
                lastLines.forEach { requestTranslation(it.text) }
                render()
            }
            .addOnCompleteListener { proxy.close() }
    }

    private fun requestTranslation(text: String) {
        if (cache.containsKey(text) || !pending.add(text)) return
        val t = translator ?: return
        t.translate(text)
            .addOnSuccessListener { cache[text] = it; pending.remove(text); render() }
            .addOnFailureListener { pending.remove(text) }
    }

    private fun render() {
        overlay.setItems(lastLines.mapNotNull { l ->
            cache[l.text]?.let { OverlayItem(l.box, it) }
        })
    }

    override fun onDestroy() {
        super.onDestroy()
        translator?.close()
        recognizer.close()
        analysisExecutor.shutdown()
    }
}
